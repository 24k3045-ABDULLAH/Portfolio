// ====== ADMIN LOGIN ======
const ADMIN_USER = "Abdullah";
const ADMIN_PASS = "-200Oo32";

function handleAdminLogin() {
  const loginForm = document.getElementById('adminLoginForm');
  if (!loginForm) return;

  loginForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const username = document.getElementById('adminUsername').value.trim();
    const password = document.getElementById('adminPassword').value.trim();

    if (username === ADMIN_USER && password === ADMIN_PASS) {
      localStorage.setItem('isAdminLoggedIn', 'true');
      window.location.href = 'admin-panel.html';
    } else {
      document.getElementById('loginError').textContent = "Invalid credentials!";
    }
  });
}
function getQueryParams() {
  const params = {};
  const queryString = window.location.search.substring(1);
  const vars = queryString.split('&');
  for (let i = 0; i < vars.length; i++) {
    const pair = vars[i].split('=');
    params[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1]);
  }
  return params;
}


// ====== SAVE DATA FUNCTIONS ======
function saveBookingData(booking) {
  const all = JSON.parse(localStorage.getItem('bookings') || '[]');
  all.push(booking);
  localStorage.setItem('bookings', JSON.stringify(all));
}

function saveApprovedBooking(booking) {
  const approved = JSON.parse(localStorage.getItem('approvedBookings') || '[]');
  approved.push(booking);
  localStorage.setItem('approvedBookings', JSON.stringify(approved));
}

function saveContactData(contact) {
  const all = JSON.parse(localStorage.getItem('contacts') || '[]');
  all.push(contact);
  localStorage.setItem('contacts', JSON.stringify(all));
}

function saveFeedbackData(feedback) {
  const all = JSON.parse(localStorage.getItem('feedbacks') || '[]');
  all.push(feedback);
  localStorage.setItem('feedbacks', JSON.stringify(all));
}

// ====== PRICES ======
const ROOM_PRICES = {
  Single: 3000,
  Double: 5000,
  Suite: 8000
};

// ====== HELPER: Get URL parameters ======


// ====== BOOKING FORM ======
function handleBookingForm() {
  const form = document.getElementById('bookingForm');
  if (!form) return;

  const checkinEl = document.getElementById('checkin');
  const checkoutEl = document.getElementById('checkout');
  const roomTypeEl = document.getElementById('roomType');
  const priceDisplay = document.getElementById('totalPrice');

  const hotelNameInput = document.getElementById('hotelName');
  const priceInput = document.getElementById('price');

  // URL parameters se hotel & price prefill
  const params = getQueryParams();
  if (hotelNameInput && params.hotel) {
    hotelNameInput.value = params.hotel;
  }
  if (priceInput && params.price) {
    priceInput.value = params.price;
  }

  function updatePrice() {
    const checkin = new Date(checkinEl.value);
    const checkout = new Date(checkoutEl.value);
    const roomType = roomTypeEl.value;

    if (!checkin || !checkout || !roomType || checkout <= checkin) {
      priceDisplay.textContent = '';
      return;
    }

    const days = Math.ceil((checkout - checkin) / (1000 * 60 * 60 * 24));
    
    // Agar URL se price aaya hai, us se total calculate karo
    if (priceInput && priceInput.value) {
      const pricePerDay = parseInt(priceInput.value, 10);
      const total = days * pricePerDay;
      priceDisplay.textContent = `Total Price: Rs ${total}`;
    } else {
      // Agar URL price nahi, toh default ROOM_PRICES ka use karo
      const total = days * ROOM_PRICES[roomType];
      priceDisplay.textContent = `Total Price: Rs ${total}`;
    }
  }

  checkinEl.addEventListener('change', updatePrice);
  checkoutEl.addEventListener('change', updatePrice);
  roomTypeEl.addEventListener('change', updatePrice);

  form.addEventListener('submit', function (event) {
    event.preventDefault();

    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const checkin = checkinEl.value;
    const checkout = checkoutEl.value;
    const roomType = roomTypeEl.value;
    const people = document.getElementById('people').value;
    const hotelName = hotelNameInput ? hotelNameInput.value : '';
    const priceVal = priceInput ? priceInput.value : '';

    if (!name || !email || !checkin || !checkout || !roomType || !people || !hotelName || !priceVal) {
      alert('Please fill in all fields');
      return;
    }

    const days = Math.ceil((new Date(checkout) - new Date(checkin)) / (1000 * 60 * 60 * 24));
    const totalPrice = days * parseInt(priceVal, 10);

    saveBookingData({ name, email, checkin, checkout, roomType, people, totalPrice, hotelName });

    alert(`Thank you, ${name}! Your booking for ${hotelName} has been received.`);

    form.reset();
    priceDisplay.textContent = '';

    // Form reset hone ke baad dobara hotel aur price inputs URL params se set karo
    if (hotelNameInput && params.hotel) {
      hotelNameInput.value = params.hotel;
    }
    if (priceInput && params.price) {
      priceInput.value = params.price;
    }
  });
}

// ====== CONTACT FORM ======
function handleContactForm() {
  const form = document.getElementById('contactForm');
  if (!form) return;

  form.addEventListener('submit', function (event) {
    event.preventDefault();

    const name = document.getElementById('contactName').value.trim();
    const email = document.getElementById('contactEmail').value.trim();
    const message = document.getElementById('message').value.trim();

    if (!name || !email || !message) {
      alert('Please fill in all fields.');
      return;
    }

    saveContactData({ name, email, message });
    alert('Thank you, ' + name + '! Your message has been sent.');
    form.reset();
  });
}

// ====== FEEDBACK FORM ======
function handleFeedbackForm() {
  const form = document.getElementById('feedbackForm');
  if (!form) return;

  form.addEventListener('submit', function(e) {
    e.preventDefault();

    const name = form.name.value.trim();
    const email = form.email.value.trim();
    const rating = form.rating.value;
    const comments = form.comments.value.trim();

    if (!name || !email || !rating) {
      alert('Please fill in all required fields');
      return;
    }

    const feedbackData = {
      name,
      email,
      rating: parseInt(rating),
      comments
    };

    saveFeedbackData(feedbackData);

    const thankyouMessage = document.getElementById('thankyouMessage');
    if (thankyouMessage) {
      thankyouMessage.textContent = 'Thank you for your feedback!';
    }

    form.reset();

    setTimeout(() => {
      if (thankyouMessage) {
        thankyouMessage.textContent = '';
      }
    }, 5000);
  });
}

// ====== ADMIN PANEL LOADER ======
function loadAdminPanel() {
  if (!localStorage.getItem('isAdminLoggedIn')) {
    alert("Access Denied. Please login first.");
    window.location.href = 'admin-login.html';
    return;
  }

  const bookingData = JSON.parse(localStorage.getItem('bookings') || '[]');
  const approvedData = JSON.parse(localStorage.getItem('approvedBookings') || '[]');
  const contactData = JSON.parse(localStorage.getItem('contacts') || '[]');
  const feedbackData = JSON.parse(localStorage.getItem('feedbacks') || '[]');

  const bookingList = document.getElementById('bookingContent');
  const approvedList = document.getElementById('approvedContent');
  const contactList = document.getElementById('contactContent');
  const feedbackList = document.getElementById('feedbackContent');

  if (bookingList) bookingList.innerHTML = '';
  if (approvedList) approvedList.innerHTML = '';
  if (contactList) contactList.innerHTML = '';
  if (feedbackList) feedbackList.innerHTML = '';

  bookingData.forEach((booking, index) => {
    const div = document.createElement('div');
    div.className = "booking-item";
    div.innerHTML = `
      <p><strong>${booking.name}</strong> booked from ${booking.checkin} to ${booking.checkout}</p>
      <p>Hotel: ${booking.hotelName || 'N/A'}</p>
      <p>Room: ${booking.roomType} | Guests: ${booking.people}</p>
      <p>Email: ${booking.email}</p>
      <p><strong>Total Price: Rs ${booking.totalPrice}</strong></p>
      <button class="approve-btn" onclick="approveBooking(${index})">Approve</button>
    `;
    bookingList.appendChild(div);
  });

  approvedData.forEach(booking => {
    const div = document.createElement('div');
    div.className = "booking-item";
    div.innerHTML = `
      <p><strong>${booking.name}</strong> (Approved)</p>
      <p>Hotel: ${booking.hotelName || 'N/A'}</p>
      <p>${booking.checkin} to ${booking.checkout} | ${booking.roomType}</p>
      <p>Guests: ${booking.people} | Email: ${booking.email}</p>
      <p><strong>Total Price: Rs ${booking.totalPrice}</strong></p>
    `;
    approvedList.appendChild(div);
  });

  contactData.forEach(contact => {
    const div = document.createElement('div');
    div.className = "booking-item";
    div.innerHTML = `
      <p><strong>${contact.name}</strong> (${contact.email})</p>
      <p>${contact.message}</p>
    `;
    contactList.appendChild(div);
  });

  feedbackData.forEach(fb => {
    const div = document.createElement('div');
    div.className = "booking-item";
    div.innerHTML = `
      <p><strong>${fb.name}</strong> (${fb.email})</p>
      <p>Rating: ${'⭐'.repeat(fb.rating)} (${fb.rating})</p>
      <p>Comments: ${fb.comments || 'No additional comments.'}</p>
    `;
    feedbackList.appendChild(div);
  });
}

// ====== APPROVE BOOKING ======
function approveBooking(index) {
  const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
  const approvedBooking = bookings.splice(index, 1)[0];

  saveApprovedBooking(approvedBooking);
  localStorage.setItem('bookings', JSON.stringify(bookings));

  alert(`Booking by ${approvedBooking.name} approved!`);
  loadAdminPanel();
}

// ====== TOGGLE SECTIONS IN ADMIN PANEL ======
function toggleSection(sectionId) {
  const allSections = ['bookingList', 'approvedList', 'contactList', 'feedbackList'];
  allSections.forEach(id => {
    const section = document.getElementById(id);
    if (section) section.style.display = (id === sectionId) ? 'block' : 'none';
  });

  loadAdminPanel(); // Refresh view with latest data
}

// ====== INIT ======
function init() {
  const path = window.location.pathname;

  if (path.includes('admin-login.html')) {
    handleAdminLogin();
  } else if (path.includes('admin-panel.html')) {
    loadAdminPanel();
  } else {
    handleBookingForm();
    handleContactForm();
    handleFeedbackForm();
  }
}

window.addEventListener('DOMContentLoaded', init);
